^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package gripper_action_controller
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.9.4 (2017-07-01)
------------------

0.9.3 (2016-02-12)
------------------

0.9.2 (2015-05-04)
------------------

0.9.1 (2014-11-03)
------------------

0.9.0 (2014-10-31)
------------------
* Buildsystem fixes
* Contributors: Adolfo Rodriguez Tsouroukdissian, Lukas Bulwahn

0.8.1 (2014-07-11)
------------------

0.8.0 (2014-05-12)
------------------

0.7.2 (2014-04-01)
------------------
* Added missing deps to package.xml
* Contributors: Scott K Logan

0.7.1 (2014-03-31)
------------------

0.7.0 (2014-03-28)
------------------
* gripper_action_controller: New controller for single dof grippers.
* Contributors: Sachin Chitta.
